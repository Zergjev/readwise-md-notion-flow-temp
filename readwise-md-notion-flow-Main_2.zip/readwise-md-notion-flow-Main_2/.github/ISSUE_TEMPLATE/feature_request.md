---
name: "Feature request"
about: Propose a focused enhancement or fix
title: "[Feature] <short title>"
labels: enhancement
assignees: ''
---

## Goal
<What do you want to add/change?>

## Context
Paste Mini Context below (from `PROJECT_CONTEXT.md`):

