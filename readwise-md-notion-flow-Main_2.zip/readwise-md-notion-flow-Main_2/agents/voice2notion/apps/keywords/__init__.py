"""
Keywords extractor app (Step 4.5) for Voice2Notion.

Produces 5 one-word keywords per transcript, saved as <stem>-keywrd.txt.
"""
