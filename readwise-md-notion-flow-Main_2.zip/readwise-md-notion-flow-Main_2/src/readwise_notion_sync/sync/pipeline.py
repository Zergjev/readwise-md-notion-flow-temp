from ..utils.settings import settings

def run_sync():
    # placeholder so `rn sync` runs today
    _ = settings
    return {"created": 0, "updated": 0, "skipped": 0}

