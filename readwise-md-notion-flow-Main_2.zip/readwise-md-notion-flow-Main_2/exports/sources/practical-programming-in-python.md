# Practical Programming in Python — Jeffrey Elkner.
_Category:_ books

- Type print ’hello’ at the prompt. _(loc 464)_
  
  ↳ **Note:** Like this
  
  ↳ _Highlighted at:_ 2011-02-06T04:56:00Z