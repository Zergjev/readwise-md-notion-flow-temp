# Digital Stockholm Syndrome in the Post-Ontological Age (Forerunners — Mark Jarzombek
_Category:_ books

- We live in a globalized world of global globalism. _(loc 90)_
  
  ↳ _Highlighted at:_ 2019-01-05T04:56:00Z