# Fifty Shades of Grey — E L James
_Category:_ books

- okay, mega-successful, _(loc 159)_
  
  ↳ *Tags:* discard
  
  ↳ _Highlighted at:_ 2013-06-15T04:56:00Z
- I could see that he was lord of all he surveyed. I realize I’m biting my lip, and I hope Kate doesn’t notice. But she seems absorbed _(loc 342)_
  
  ↳ _Highlighted at:_ 2013-06-15T04:56:00Z
- simply. Dominating Christian, _(loc 1749)_
  
  ↳ _Highlighted at:_ 2013-06-15T04:56:00Z
- blurt out the question, _(loc 1764)_
  
  ↳ _Highlighted at:_ 2013-06-15T04:56:00Z